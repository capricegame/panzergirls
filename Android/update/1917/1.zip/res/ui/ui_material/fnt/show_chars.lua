
local f, e = io.popen("dir /b")
assert(f, e)


local charIDs = {}
for l in f:lines() do
    local f1 = io.open(l)
    if f1 then 
        print("process File:", l)
        local data = f1:read("*a")
        for charID in string.gmatch(data, "char id=(%d+)") do
            table.insert(charIDs, charID)
        end
        
        break
    end
end

print(s)
